// chatgpt_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatGPTService {
  final String apiKey = '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';

  Future<String> sendMessage(String message) async {
    const apiUrl = 'https://api.openai.com/v1/chat/completions';

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        "model": "gpt-3.5-turbo",
        "messages": [
          {"role": "user", "content": message}
        ]
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final reply = data['choices'][0]['message']['content'];
      return reply.trim();
    } else {
      return 'Erreur : ${response.statusCode}';
    }
  }
}